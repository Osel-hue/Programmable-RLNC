const char GIT_Version[] = "git:v4.4.2";
const char *git_version(void) {
    return GIT_Version;
}
